<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" id="mainLayout">
	<head>
		<title>Travian comx</title>
<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="pragma" content="no-cache" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="content-type"	content="text/html; charset=UTF-8" />
<meta name="content-language" content="en" />
<link href="//gpack.travian.com/49c13504/lang/en/compact.css?a0ba9" rel="stylesheet" type="text/css" /><link href="//gpack.travian.com/49c13504/lang/en/lang.css?a0ba9" rel="stylesheet" type="text/css" /><link href="img/travian_basics.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="crypt.js?1465910315"></script>
<script type="text/javascript">
Travian.Translation.add(
{
	'allgemein.anleitung':	'Instructions',
	'allgemein.cancel':	'cancel',
	'allgemein.ok':	'OK',
	'allgemein.close':	'close',
	'cropfinder.keine_ergebnisse': 'No search results found.'
});
Travian.applicationId = 'T4.4 Game';
Travian.Game.version = '4.4';
Travian.Game.worldId = 'comx18';
Travian.Game.speed = 3;

Travian.Templates = {};
	Travian.Templates.ButtonTemplate = "<button >\n\t<div class=\"button-container addHoverClick\">\n\t\t<div class=\"button-background\">\n\t\t\t<div class=\"buttonStart\">\n\t\t\t\t<div class=\"buttonEnd\">\n\t\t\t\t\t<div class=\"buttonMiddle\"><\/div>\n\t\t\t\t<\/div>\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t<div class=\"button-content\"><\/div>\n\t<\/div>\n<\/button>\n";

</script>
<script type="text/javascript">
window.addEvent('domready', function() {
		Travian.Form.UnloadHelper.message = 'You have made changes. Do you really want to leave this page?';
});
</script>	</head>
	<body class="v35  login perspectiveBuildings  ltr">
		
		<script type="text/javascript">
			window.ajaxToken = '7a54c8c229debfe39edf8d3fe7912491';
		</script>
				<div id="background">
									<div id="bodyWrapper">
								<img style="filter:chroma();" src="img/x.gif" id="msfilter" alt="" />

				<div id="header">
	<a id="logo" href="http://www.travian.com/" target="_blank" title="Travian" ></a>

	
	
	
	
	</div>
				<div id="center">

					<div id="sidebarBeforeContent" class="sidebar beforeContent">
					
<div id="sidebarBoxMenu" class="sidebarBox   ">
	<div class="sidebarBoxBaseBox">
		<div class="baseBox baseBoxTop">
			<div class="baseBox baseBoxBottom">
				<div class="baseBox baseBoxCenter"></div>
			</div>
		</div>
	</div>
	<div class="sidebarBoxInnerBox">
		<div class="innerBox header noHeader">
					</div>
		<div class="innerBox content">
			<ul>
	<li class="first">
		<a href="http://www.travian.com/" title="Homepage" target="_blank">HOMEPAGE</a>
	</li>

	<li class="active">
		<a href="login.php" title="Login">LOGIN</a>
	</li>

	<li >
		<a href="http://www.travian.com/index.php?server=comx#register" title="Register" target="_blank">REGISTER</a>
	</li>

	<li>
		<a href="http://forum.travian.com" title="Forum" target="_blank">FORUM</a>
	</li>

	<li >
		<a href="support.php" title="Support">SUPPORT</a>
	</li>
</ul>		</div>
		<div class="innerBox footer">
					</div>
	</div>
</div>						<div class="clear"></div>
					</div>

					<div id="contentOuterContainer" class="size1">
												<div class="contentTitle">
							<a id="answersButton" class="contentTitleButton" href="http://t4.answers.travian.com/index.php?aid=8#go2answer" target="_blank" title="Travian Answers">&nbsp;</a>						</div>
						<div class="contentContainer">
							<div id="content" class="login">
								<h1 class="titleInHeader">
	Login</h1>

<script type="text/javascript">
Element.implement({
	 //imgid: falls zu dem link ein pfeil gehört kann dieser "auf/zugeklappt" werden
	 showOrHide: function(imgid) {
		 //einblenden
		 if (this.getStyle('display') == 'none')
		 {
			 if (imgid != '')
			 {
				 $(imgid).className = 'open';
			 }
		 }
		 //ausblenden
		 else
		 {
			 if (imgid != '')
			 {
				 $(imgid).className = 'close';
			 }
		 }
		 this.toggleClass('hide');
	}
});
</script>

<div class="outerLoginBox">
	<h2>Welcome to server Travian comx!</h2>
		<noscript>
		<div class="noJavaScript">
			JavaScript is deactivated. You must activate it in your browser settings to be able to play Travian.		</div>
	</noscript>
		<div class="innerLoginBox">
		<form name="login" method="POST" action="dorf1.php">
			<table class="transparent loginTable">
				<tr class="account">
					<td class="accountNameOrEmailAddress">
						Account name or e-mail address					</td>
					<td>
						<input type="text" name="name" value="" class="text" /><br />
						<div class="error LTR" style="width:145px;">
													</div>
					</td>
					<td>
					</td>
				</tr>
				<tr class="pass">
					<td>
						Password					</td>
					<td>
						<input type="password" maxlength="100" name="password" value="" class="text" /><br />
						<div class="error LTR">
													</div>
					</td>
					<td>
					</td>
				</tr>
													<tr class="lowResOption">
						<td>
							Version for player						</td>
						<td colspan="2">
							<input type="checkbox" class="check" id="lowRes" name="lowRes" value="1"	 />
							<label for="lowRes">with low bandwidth (internet connection speed)</label>
						</td>
					</tr>
					<tr class="lowResInfo">
						<td colspan="3">
							(Note: this version of the map doesn&#39;t have all the options enabled)						</td>
					</tr>
								<tr class="loginButtonRow">
					<td>
					</td>
					<td>
						<button  type="submit" value="Login" name="s1" id="s1" class="green " onclick="document.login.w.value=screen.width+':'+screen.height;">
	<div class="button-container addHoverClick">
		<div class="button-background">
			<div class="buttonStart">
				<div class="buttonEnd">
					<div class="buttonMiddle"></div>
				</div>
			</div>
		</div>
		<div class="button-content">Login</div>
	</div>
</button>
<script type="text/javascript" id="s1_script">
	window.addEvent('domready', function()
	{
	if($('s1'))
	{
		$('s1').addEvent('click', function ()
		{
			window.fireEvent('buttonClicked', [this, {"type":"submit","value":"Login","name":"s1","id":"s1","class":"green ","title":"","confirm":"","onclick":"document.login.w.value=screen.width+\u0027:\u0027+screen.height;"}]);
		});
	}
	});
</script>
						<input type="hidden" name="w" value="" />
						<input type="hidden" name="login" value="1466695228" />
					</td>
					<td>
					</td>
				</tr>
			</table>
		</form>
	</div>
	

			<div class="greenbox passwordForgotten">
				<div class="greenbox-top"></div>
				<div class="greenbox-content">
			 <div class="passwordForgottenLink">
	 	<a onclick="" href="?forgotPassword=true" class="showPWForgottenLink">
	 		<img class="close" id="arrow" src="img/x.gif" alt="forgotten password"/>Password forgotten?	 	</a>
	 </div>
	 
				</div>
				<div class="greenbox-bottom"></div>
				<div class="clear"></div>
			</div>
		</div>
								<div class="clear"></div>
							</div>
							<div class="clear">&nbsp;</div>
						</div>
						<div class="contentFooter"></div>
					</div>

					<div id="sidebarAfterContent" class="sidebar afterContent ">
						
<div id="sidebarBoxNews3" class="sidebarBox   sidebarBoxNews">
	<div class="sidebarBoxBaseBox">
		<div class="baseBox baseBoxTop">
			<div class="baseBox baseBoxBottom">
				<div class="baseBox baseBoxCenter"></div>
			</div>
		</div>
	</div>
	<div class="sidebarBoxInnerBox">
		<div class="innerBox header noHeader">
					</div>
		<div class="innerBox content">
			<a href="#" onclick="
	$H(
	{
		data:
		{
			cmd: 'news',
			id: '3'
		}
	}).dialog(); return false;">PTR starts on 15.6.2016 as Travian: Legends speed 2x Public Test Real server! The registration opens on Monday, May 13, 2016.</a>		</div>
		<div class="innerBox footer">
				<a target="_blank" href="http://forum.travian.com/showthread.php?t=156524">...more information</a>
		</div>
	</div>
</div>
<div id="sidebarBoxNews4" class="sidebarBox   sidebarBoxNews">
	<div class="sidebarBoxBaseBox">
		<div class="baseBox baseBoxTop">
			<div class="baseBox baseBoxBottom">
				<div class="baseBox baseBoxCenter"></div>
			</div>
		</div>
	</div>
	<div class="sidebarBoxInnerBox">
		<div class="innerBox header noHeader">
					</div>
		<div class="innerBox content">
			<a href="#" onclick="
	$H(
	{
		data:
		{
			cmd: 'news',
			id: '4'
		}
	}).dialog(); return false;">COMX started on 20.5.2016 as Travian: Legends 3x-speed server! The registration is open.</a>		</div>
		<div class="innerBox footer">
				<a target="_blank" href="http://forum.travian.com/showthread.php?t=156460">...more information</a>
		</div>
	</div>
</div>						<div class="clear"></div>
					</div>

					<div class="clear"></div>
				</div>

				<div id="footer" class="size1">
					<div id="pageLinks">
						<a href="http://www.travian.com/" target="_blank">Homepage</a>
						<a href="http://forum.travian.com" target="_blank">Forum</a>
						<a href="http://www.travian.com/links.php" target="_blank">Links</a>
						<a href="http://t4.answers.travian.com/" target="_blank">FAQ - Answers</a>
						<a href="http://www.travian.com/spielregeln.php" target="_blank">Game rules</a>
						<a href="http://www.travian.com/agb.php" target="_blank">Terms</a>
						<a href="http://www.travian.com/impressum.php" target="_blank">Imprint</a>
						<div class="clear"></div>
											</div>
					<p class="copyright">© 2004 - 2016 Travian Games GmbH</p>
				</div>

							</div>

			
			<div id="ce"></div>

			
					</div>
		<script type="text/javascript">
			var T4_feature_flags = {"aeu":false,"vacationMode":true,"territory":false};
		</script>

		
		<iframe
	src="https://analytics.traviangames.com/piwik_route.php?app=TRAVIAN&amp;ts=1466695228&amp;tld=en"
	style="position: absolute; height: 0px; left: 0px; overflow: hidden; top: 0px; visibility: hidden; width: 0px;"
></iframe>
			</body>
</html>