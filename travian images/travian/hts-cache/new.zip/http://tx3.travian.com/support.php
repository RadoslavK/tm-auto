<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" id="mainLayout">
	<head>
		<title>Travian comx</title>
<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="pragma" content="no-cache" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="content-type"	content="text/html; charset=UTF-8" />
<meta name="content-language" content="en" />
<link href="//gpack.travian.com/49c13504/lang/en/compact.css?a0ba9" rel="stylesheet" type="text/css" /><link href="//gpack.travian.com/49c13504/lang/en/lang.css?a0ba9" rel="stylesheet" type="text/css" /><link href="img/travian_basics.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="crypt.js?1465910315"></script>
<script type="text/javascript">
Travian.Translation.add(
{
	'allgemein.anleitung':	'Instructions',
	'allgemein.cancel':	'cancel',
	'allgemein.ok':	'OK',
	'allgemein.close':	'close',
	'cropfinder.keine_ergebnisse': 'No search results found.'
});
Travian.applicationId = 'T4.4 Game';
Travian.Game.version = '4.4';
Travian.Game.worldId = 'comx18';
Travian.Game.speed = 3;

Travian.Templates = {};
	Travian.Templates.ButtonTemplate = "<button >\n\t<div class=\"button-container addHoverClick\">\n\t\t<div class=\"button-background\">\n\t\t\t<div class=\"buttonStart\">\n\t\t\t\t<div class=\"buttonEnd\">\n\t\t\t\t\t<div class=\"buttonMiddle\"><\/div>\n\t\t\t\t<\/div>\n\t\t\t<\/div>\n\t\t<\/div>\n\t\t<div class=\"button-content\"><\/div>\n\t<\/div>\n<\/button>\n";

</script>
<script type="text/javascript">
window.addEvent('domready', function() {
		Travian.Form.UnloadHelper.message = 'You have made changes. Do you really want to leave this page?';
});
</script>	</head>
	<body class="v35  support perspectiveBuildings  ltr">
		
		<script type="text/javascript">
			window.ajaxToken = '7a54c8c229debfe39edf8d3fe7912491';
		</script>
				<div id="background">
									<div id="bodyWrapper">
								<img style="filter:chroma();" src="img/x.gif" id="msfilter" alt="" />

				<div id="header">
	<a id="logo" href="http://www.travian.com/" target="_blank" title="Travian" ></a>

	
	
	
	
	</div>
				<div id="center">

					<div id="sidebarBeforeContent" class="sidebar beforeContent">
					
<div id="sidebarBoxMenu" class="sidebarBox   ">
	<div class="sidebarBoxBaseBox">
		<div class="baseBox baseBoxTop">
			<div class="baseBox baseBoxBottom">
				<div class="baseBox baseBoxCenter"></div>
			</div>
		</div>
	</div>
	<div class="sidebarBoxInnerBox">
		<div class="innerBox header noHeader">
					</div>
		<div class="innerBox content">
			<ul>
	<li class="first">
		<a href="http://www.travian.com/" title="Homepage" target="_blank">HOMEPAGE</a>
	</li>

	<li >
		<a href="login.php" title="Login">LOGIN</a>
	</li>

	<li >
		<a href="http://www.travian.com/index.php?server=comx#register" title="Register" target="_blank">REGISTER</a>
	</li>

	<li>
		<a href="http://forum.travian.com" title="Forum" target="_blank">FORUM</a>
	</li>

	<li class="active">
		<a href="support.php" title="Support">SUPPORT</a>
	</li>
</ul>		</div>
		<div class="innerBox footer">
					</div>
	</div>
</div>						<div class="clear"></div>
					</div>

					<div id="contentOuterContainer" class="size1">
												<div class="contentTitle">
							<a id="answersButton" class="contentTitleButton" href="http://t4.answers.travian.com/index.php?aid=137#go2answer" target="_blank" title="Travian Answers">&nbsp;</a>						</div>
						<div class="contentContainer">
							<div id="content" class="support">
								<h1 class="titleInHeader">Support</h1>
You can use the following form to submit your request to the Support. Please take a bit of time to answer the form questions in as much detail as possible, so that we can answer your request quickly and in length. Please note that without a valid email address, your request will not get processed.<h3>Game errors, login errors and game rules related questions</h3>
<form method="post" name="support" id="support"><div id="group_support_gameworld"><table class="form_table form_tablel_support" width="100%"><tr><td class="form_table_label form_table_label_support_gameworld"><label class="form_label" for="support[gameworld]">Game world</label></td><td class="form_table_element form_table_element_support_gameworld"><select  id="support_gameworld" name="support[gameworld]"><option value="please_select" >please select</option><option value="i_do_not_know" >I don´t know</option><option value="com1 - http://ts1.travian.com/" >com1 - http://ts1.travian.com/</option><option value="com2 - http://ts2.travian.com/" >com2 - http://ts2.travian.com/</option><option value="com3 - http://ts3.travian.com/" >com3 - http://ts3.travian.com/</option><option value="com4 - http://ts4.travian.com/" >com4 - http://ts4.travian.com/</option><option value="com5 - http://ts5.travian.com/" >com5 - http://ts5.travian.com/</option><option value="com6 - http://ts6.travian.com/" >com6 - http://ts6.travian.com/</option><option value="com7 - http://ts7.travian.com/" >com7 - http://ts7.travian.com/</option><option value="com8 - http://ts8.travian.com/" >com8 - http://ts8.travian.com/</option><option value="AEU 2x - http://ts9.travian.com/" >AEU 2x - http://ts9.travian.com/</option><option value="comx - http://tx3.travian.com/" >comx - http://tx3.travian.com/</option><option value="Server 10 - http://ts10.travian.com/" >Server 10 - http://ts10.travian.com/</option><option value="TT 2016 Int - http://tx2.travian.com/" >TT 2016 Int - http://tx2.travian.com/</option><option value="Finals 2015 - http://finals.travian.com/" >Finals 2015 - http://finals.travian.com/</option><option value="TT Scand - http://ts62.travian.com/" >TT Scand - http://ts62.travian.com/</option><option value="TT Español - http://ts63.travian.com/" >TT Español - http://ts63.travian.com/</option><option value="TT Português - http://ts64.travian.com/" >TT Português - http://ts64.travian.com/</option><option value="TT APAC - http://ts65.travian.com/" >TT APAC - http://ts65.travian.com/</option><option value="PTR - http://ts70.travian.com/" >PTR - http://ts70.travian.com/</option><option value="Empire - http://ts19.travian.com/" >Empire - http://ts19.travian.com/</option><option value="PTR - http://ts71.travian.com/" >PTR - http://ts71.travian.com/</option><option value="Empire x2 - http://ts20.travian.com/" >Empire x2 - http://ts20.travian.com/</option><option value="Midsummer - http://ts21.travian.com/" >Midsummer - http://ts21.travian.com/</option></select></td></tr></table></div><div id="group_support_username"><table class="form_table form_tablel_support" width="100%"><tr><td class="form_table_label form_table_label_support_username"><label class="form_label" for="support[username]">Username</label></td><td class="form_table_element form_table_element_support_username"><input type="text" id="support_username" name="support[username]" class="text" label="Username" helper="" value=""/></td></tr></table></div><div id="group_support_email"><table class="form_table form_tablel_support" width="100%"><tr><td class="form_table_label form_table_label_support_email"><label class="form_label" for="support[email]">Email</label></td><td class="form_table_element form_table_element_support_email"><input type="text" id="support_email" name="support[email]" class="text" label="Email" helper="" value=""/></td></tr></table></div><div id="group_support_supportType"><table class="form_table form_tablel_support" width="100%"><tr><td class="form_table_label form_table_label_support_supportType"><label class="form_label" for="support[supportType]">Category</label></td><td class="form_table_element form_table_element_support_supportType"><select  id="support_supportType" name="support[supportType]"><option value="please_select" >please select</option><option value="general_querstions" >General questions</option><option value="i_can_not_login" >I cannot log in</option><option value="i_can_not_register" >I cannot register an account</option></select></td></tr></table></div><div id="group_support_message"><table class="form_table form_tablel_support" width="100%"><tr><td class="form_table_label form_table_label_support_message"><label class="form_label" for="support[message]">Message</label></td><td class="form_table_element form_table_element_support_message"><textarea name="support[message]" cols="43" rows="7" label="Message" helper=""></textarea></td></tr></table></div><div id="group_support_submit"><table class="form_table form_tablel_support" width="100%"><tr><td class="form_table_label form_table_label_support_submit"><label class="form_label" for="support[submit]"></label></td><td class="form_table_element form_table_element_support_submit"><button  type="submit" value="send request" name="support[submit]" id="support[submit]" class="green " submit="1">
	<div class="button-container addHoverClick">
		<div class="button-background">
			<div class="buttonStart">
				<div class="buttonEnd">
					<div class="buttonMiddle"></div>
				</div>
			</div>
		</div>
		<div class="button-content">send request</div>
	</div>
</button>
<script type="text/javascript" id="support[submit]_script">
	window.addEvent('domready', function()
	{
	if($('support[submit]'))
	{
		$('support[submit]').addEvent('click', function ()
		{
			window.fireEvent('buttonClicked', [this, {"type":"submit","value":"send request","name":"support[submit]","id":"support[submit]","class":"green ","title":"","confirm":"","onclick":"","submit":true}]);
		});
	}
	});
</script>
</td></tr></table></div>								<div class="clear"></div>
							</div>
							<div class="clear">&nbsp;</div>
						</div>
						<div class="contentFooter"></div>
					</div>

					<div id="sidebarAfterContent" class="sidebar afterContent ">
						
<div id="sidebarBoxNews3" class="sidebarBox   sidebarBoxNews">
	<div class="sidebarBoxBaseBox">
		<div class="baseBox baseBoxTop">
			<div class="baseBox baseBoxBottom">
				<div class="baseBox baseBoxCenter"></div>
			</div>
		</div>
	</div>
	<div class="sidebarBoxInnerBox">
		<div class="innerBox header noHeader">
					</div>
		<div class="innerBox content">
			<a href="#" onclick="
	$H(
	{
		data:
		{
			cmd: 'news',
			id: '3'
		}
	}).dialog(); return false;">PTR starts on 15.6.2016 as Travian: Legends speed 2x Public Test Real server! The registration opens on Monday, May 13, 2016.</a>		</div>
		<div class="innerBox footer">
				<a target="_blank" href="http://forum.travian.com/showthread.php?t=156524">...more information</a>
		</div>
	</div>
</div>
<div id="sidebarBoxNews4" class="sidebarBox   sidebarBoxNews">
	<div class="sidebarBoxBaseBox">
		<div class="baseBox baseBoxTop">
			<div class="baseBox baseBoxBottom">
				<div class="baseBox baseBoxCenter"></div>
			</div>
		</div>
	</div>
	<div class="sidebarBoxInnerBox">
		<div class="innerBox header noHeader">
					</div>
		<div class="innerBox content">
			<a href="#" onclick="
	$H(
	{
		data:
		{
			cmd: 'news',
			id: '4'
		}
	}).dialog(); return false;">COMX started on 20.5.2016 as Travian: Legends 3x-speed server! The registration is open.</a>		</div>
		<div class="innerBox footer">
				<a target="_blank" href="http://forum.travian.com/showthread.php?t=156460">...more information</a>
		</div>
	</div>
</div>						<div class="clear"></div>
					</div>

					<div class="clear"></div>
				</div>

				<div id="footer" class="size1">
					<div id="pageLinks">
						<a href="http://www.travian.com/" target="_blank">Homepage</a>
						<a href="http://forum.travian.com" target="_blank">Forum</a>
						<a href="http://www.travian.com/links.php" target="_blank">Links</a>
						<a href="http://t4.answers.travian.com/" target="_blank">FAQ - Answers</a>
						<a href="http://www.travian.com/spielregeln.php" target="_blank">Game rules</a>
						<a href="http://www.travian.com/agb.php" target="_blank">Terms</a>
						<a href="http://www.travian.com/impressum.php" target="_blank">Imprint</a>
						<div class="clear"></div>
											</div>
					<p class="copyright">© 2004 - 2016 Travian Games GmbH</p>
				</div>

							</div>

			
			<div id="ce"></div>

			
					</div>
		<script type="text/javascript">
			var T4_feature_flags = {"aeu":false,"vacationMode":true,"territory":false};
		</script>

		
		
			</body>
</html>